<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-8">
      <h1 class="h3 mb-4 text-gray-800">Cadastrar Categorias</h1>
    </div>
  </div>


  <div class="col-md-12">
    <form method="POST" action="<?php echo e(route('admin.categorias.store')); ?>">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome">
      </div>

      <div class="form-group">
        <label for="descricao">Descrição</label>
        <input type="text" class="form-control" id="descricao" name="descricao">
      </div>

      <button type="submit" class="btn btn-success">Cadastrar</button>

    </form>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/categorias/form.blade.php ENDPATH**/ ?>