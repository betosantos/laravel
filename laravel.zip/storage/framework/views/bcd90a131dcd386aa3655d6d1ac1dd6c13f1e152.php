<?php $__env->startSection('content'); ?>

  <div class="col-md-12">
    <div class="row">
      <div class="col-md-8">
        <h1 class="h3 mb-4 text-gray-800">Cursos </h1>
      </div>

      <div class="col-md-4 text-right">
        <a href="<?php echo e(route('admin.cursos.create')); ?>"><button type="button" class="btn btn-success">Cadastrar</button></a>
      </div>

    </div>
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <?php echo \Session::get('success'); ?>

      </div>
    <?php endif; ?>
  </div>

  <div class="col-md-12">
    <table class="table table-hover">
      <thead>
        <tr>
          <th width="100">Imagem</th>
          <th>Nome</th>
          <th>Categorias</th>
          <th>Preço</th>
          <th width="100" class="text-right">Ações</th>
        </tr>
      </thead>
      <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tbody>
          <tr>
            <td>
              <img class="img-responsive" src="<?php echo e(url("storage/cursos/{$curso->imagem}")); ?>" style="max-width: 130px;">              
            </td>
            <td><a href="<?php echo e(route('admin.cursos.edit', $curso->id)); ?>"><?php echo e($curso->nome); ?></a></td>
            <td>
              <ul>
                <?php $__currentLoopData = $curso->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($cat->nome); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </td>
            <td><?php echo e($curso->preco); ?></td>
            <td class="text-right">
              <a href="<?php echo e(route('admin.cursos.edit', $curso->id)); ?>"><i class="fa fa-pencil fa-lg" aria-hidden="true"></i></a>
              &nbsp;
              <a href="<?php echo e(route('admin.cursos.destroy', $curso->id)); ?>"><i class="fa fa-trash fa-lg" aria-hidden="true" style="color: red;"></i></a>
            </td>
          </tr>
        </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-warning text-center">
          <p><strong>Não Há Cursos Cadastradas !! </p></strong>
        </div>
      <?php endif; ?>
    </table>
    <?php echo e($cursos->links()); ?>

  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/cursos/index.blade.php ENDPATH**/ ?>