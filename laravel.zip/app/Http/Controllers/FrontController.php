<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontController extends Controller
{
  public function front()
  {
    return view('front.index');
  }


  public function contato()
  {
    return view('front.contato');
  }


  public function sobre()
  {
    return view('front.sobre');
  }


  public function curso()
  {
    return view('front.curso');
  }


  public function detalhes($id)
  {
    return view('front.detalhes');
  }


}
